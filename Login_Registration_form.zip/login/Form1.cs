﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;


namespace login
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Class1 c2 = new Class1();
            string unm = txtunm.Text;
            string pwd = txtpwd.Text;
            string query = "select * from loginInfo where username='" + unm + "' and password ='" + pwd + "'";
            SqlDataAdapter da = new SqlDataAdapter(query, c2.cn);
            DataTable dt1 = new DataTable();
            int a= da.Fill(dt1);

            if (a >= 0)
            {
                home h1 = new home();
                this.Close();
                h1.Show();
            }
        }


        private void label1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            this.Close();
            f2.Show();
        }

        private void Login_Load(object sender, EventArgs e)
        {
           
        }
    }
}
