﻿namespace login
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.textboxunm = new System.Windows.Forms.TextBox();
            this.textpwd = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.Label();
            this.CreateUser = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(27, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "username";
            // 
            // textboxunm
            // 
            this.textboxunm.Location = new System.Drawing.Point(86, 29);
            this.textboxunm.Name = "textboxunm";
            this.textboxunm.Size = new System.Drawing.Size(164, 20);
            this.textboxunm.TabIndex = 1;
            // 
            // textpwd
            // 
            this.textpwd.Location = new System.Drawing.Point(86, 66);
            this.textpwd.Name = "textpwd";
            this.textpwd.Size = new System.Drawing.Size(164, 20);
            this.textpwd.TabIndex = 3;
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Location = new System.Drawing.Point(27, 69);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(52, 13);
            this.Password.TabIndex = 2;
            this.Password.Text = "password";
            // 
            // CreateUser
            // 
            this.CreateUser.Location = new System.Drawing.Point(71, 105);
            this.CreateUser.Name = "CreateUser";
            this.CreateUser.Size = new System.Drawing.Size(120, 19);
            this.CreateUser.TabIndex = 4;
            this.CreateUser.Text = "Create User";
            this.CreateUser.UseVisualStyleBackColor = true;
            this.CreateUser.Click += new System.EventHandler(this.CreateUser_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(292, 160);
            this.Controls.Add(this.CreateUser);
            this.Controls.Add(this.textpwd);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.textboxunm);
            this.Controls.Add(this.label1);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textboxunm;
        private System.Windows.Forms.TextBox textpwd;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.Button CreateUser;
    }
}