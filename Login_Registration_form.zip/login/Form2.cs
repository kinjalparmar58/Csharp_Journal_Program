﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace login
{
    public partial class Form2 : Form
    {
      
        public Form2()
        {
            InitializeComponent();
        }

        private void CreateUser_Click(object sender, EventArgs e)
        {
            Class1 c1 = new Class1();
            DataColumn dcid = new System.Data.DataColumn("ID", typeof(int));
            dcid.AutoIncrement = true;
            string sql = "Insert into loginInfo values('"+textboxunm.Text+"','"+textpwd.Text+"')";
            SqlDataAdapter da = new SqlDataAdapter(sql, c1.cn);
            DataTable dt = new DataTable();
            int a = da.Fill(dt);

            if (a >= 0)
            {
                MessageBox.Show("Created..!!!");
            }
        }

    }
}
