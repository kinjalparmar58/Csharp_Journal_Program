﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxingUnboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            Object obj = a;
            Console.WriteLine("obj type value:"+ obj);

            int b = (int)obj;
            Console.WriteLine(" type value:" +b );
            Console.Read();
        }
    }
}
