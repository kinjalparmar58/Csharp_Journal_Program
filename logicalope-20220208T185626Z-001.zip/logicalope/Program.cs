﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace logicalope
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b,c;

            Console.WriteLine("Enter Value of A & B & c :");
            a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            c = Convert.ToInt32(Console.ReadLine());

            if (a==b && b==c)
            {
                Console.WriteLine("a = b = c");
            }
            Console.Read();
        }
    }
}
