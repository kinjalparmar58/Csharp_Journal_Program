﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_Dimensional
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            int[] x;

            x = new int[5];
            Console.Write("Enter Elements:\n");
            for (i = 0; i < 5; i++)
            {
                Console.Write("\t Element[" + i + "]:");
                x[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.Write("\n\nElement are:\n");
            for (i = 0; i < 5; i++)
            {
                Console.WriteLine("\tElement[" + i + "]:" + x[i]);
            }
            Console.Read();
        }
    }
}
