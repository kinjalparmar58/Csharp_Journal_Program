﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_2_3_for_
{
    class Program
    {
        static void Main(string[] args)
        {
            int i ;

           Console.WriteLine("FOR LOOP :");
            for (i = 1; i <= 5; i++)
            {
                Console.WriteLine(i + " ");
            }

             Console.WriteLine("WHILE LOOP :");
            i = 1;
            while(i<=5)
            {
                Console.WriteLine(i + " ");   
                i++;
            }

            Console.WriteLine("DO...LOOP :");
            i = 1;
            do
            {
                Console.WriteLine(i + " ");
                i++;
            } while (i <= 5);
          
            Console.Read();
        }
    }
}
